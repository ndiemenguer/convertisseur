import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import Exo2 from './Exo2.jsx'
import Exo3 from './Exo3.jsx'
import Exo4 from './Exo4.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
 /* <React.StrictMode>
    <App />
  </React.StrictMode>,*/

      /*<React.StrictMode>
      <Exo2 />
      </React.StrictMode>,*/

      /*<React.StrictMode>
      <Exo3 />
      </React.StrictMode>,*/

        <React.StrictMode>
        <Exo4 />
        </React.StrictMode>,
)
